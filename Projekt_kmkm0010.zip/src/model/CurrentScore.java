package model;

public class CurrentScore {
    private int score;

    public CurrentScore(int cs) {
        score = cs;
    }

    public int getScore() {
        return score;
    }
}
