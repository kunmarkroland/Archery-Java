import view.GameFrame;

public class Main{
    static void main(String[] args) {
        new GameFrame();
    }
}